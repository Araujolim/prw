<?php
    $n1=4;
    $n2=3;
    $mult=0;
    for($n=0; $n<=$n2; $n++){
        $mult = $mult + $n1;
    }

    echo "A multiplicação: ". $mult;


?>